package com.student.registration.student_registration_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRegistrationBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
